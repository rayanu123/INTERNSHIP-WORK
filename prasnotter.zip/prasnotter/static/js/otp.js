var i = 19;
var time = $("#time")
var timer = setInterval(function() {
  time.html(i);
  if (i == 0) {
    $('#hideresend').hide();
    $("#resendbtn").show();
    clearInterval(timer);

  }
  i--;
}, 1000)