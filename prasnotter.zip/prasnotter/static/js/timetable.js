
navbar=document.querySelector(".navbar").querySelectorAll("a");

navbar.forEach(element => {
    element.addEventListener("click",function(){
        // navbar.forEach(nav=>nav.classList.remove("active"))
        this.classList.add("active");
    })
});


$(document).ready(function(){
  var Name1=$('#name1').text();
  var str2 = Name1.match(/\b(\w)/g);
  if(str2[0]==='A' || str2[0]==='a' || str2[0]==='Z' || str2[0]==='z'){
    $("#profileImage").css("background-color","burlywood")
    $("#profileImage1").css("background-color","burlywood")
  }
  if(str2[0]==='B' || str2[0]==='b' || str2[0]==='Y' || str2[0]==='y'){
    $("#profileImage").css("background-color","yellowgreen")
    $("#profileImage1").css("background-color","yellowgreen")
  }
  if(str2[0]==='C' || str2[0]==='c' || str2[0]==='X' || str2[0]==='x'){
    $("#profileImage").css("background-color","cadetblue")
    $("#profileImage1").css("background-color","cadetblue")
  }
  if(str2[0]==='D' || str2[0]==='d' || str2[0]==='W' || str2[0]==='w'){
    $("#profileImage").css("background-color","deepskyblue")
    $("#profileImage1").css("background-color","deepskyblue")
  }
  if(str2[0]==='E' || str2[0]==='e' || str2[0]==='V' || str2[0]==='v'){
    $("#profileImage").css("background-color","chartreuse")
    $("#profileImage1").css("background-color","chartreuse")
  }
  if(str2[0]==='F' || str2[0]==='f' || str2[0]==='U' || str2[0]==='u'){
    $("#profileImage").css("background-color","firebrick")
    $("#profileImage1").css("background-color","firebrick")
  }
  if(str2[0]==='G' || str2[0]==='g' || str2[0]==='T' || str2[0]==='t'){
    $("#profileImage").css("background-color","grey")
    $("#profileImage1").css("background-color","grey")
  }
  if(str2[0]==='P' || str2[0]==='p' || str2[0]==='S' || str2[0]==='s'){
    $("#profileImage").css("background-color","peru")
    $("#profileImage1").css("background-color","peru")
  }
  if(str2[0]==='I' || str2[0]==='i' || str2[0]==='R' || str2[0]==='r'){
    $("#profileImage").css("background-color","indianred")
    $("#profileImage1").css("background-color","indianred")
  }
  if(str2[0]==='J' || str2[0]==='j' || str2[0]==='Q' || str2[0]==='q'){
    $("#profileImage").css("background-color","turquoise")
    $("#profileImage1").css("background-color","turquoise")
  }
  if(str2[0]==='K' || str2[0]==='k' || str2[0]==='O' || str2[0]==='o'){
    $("#profileImage").css("background-color","olive")
    $("#profileImage1").css("background-color","olive")
  }
  if(str2[0]==='L' || str2[0]==='l' || str2[0]==='N' || str2[0]==='n'){
    $("#profileImage").css("background-color","navy")
    $("#profileImage1").css("background-color","navy")
  }
  if(str2[0]==='M' || str2[0]==='m' || str2[0]==='H' || str2[0]==='h'){
    $("#profileImage").css("background-color","magenta")
    $("#profileImage1").css("background-color","magenta")
  }
  
  
  
  if(str2[1]===undefined){
    var intials = str2[0];
  }
  else{
    var intials = str2[0]+str2[1];
  }
  var profileImage = $('#profileImage').text(intials);
});

$(document).ready(function(){
  var Name=$('#name').text();
  var str1 = Name.match(/\b(\w)/g);
  if(str1[1]===undefined){
    var intials1 = str1[0];
  }
  else{
    var intials1 = str1[0]+str1[1];
  }
  var profileImage1 = $('#profileImage1').text(intials1);
});

console.log(document.querySelector('#profileImage'))



//   const date = new Date();

// const renderCalendar = () => {
//   date.setDate(1);

//   const monthDays = document.querySelector(".days");

//   const lastDay = new Date(
//     date.getFullYear(),
//     date.getMonth() + 1,
//     0
//   ).getDate();

//   const prevLastDay = new Date(
//     date.getFullYear(),
//     date.getMonth(),
//     0
//   ).getDate();

//   const firstDayIndex = date.getDay();

//   const lastDayIndex = new Date(
//     date.getFullYear(),
//     date.getMonth() + 1,
//     0
//   ).getDay();

//   const nextDays = 7 - lastDayIndex - 1;

//   const months = [
//     "January",
//     "February",
//     "March",
//     "April",
//     "May",
//     "June",
//     "July",
//     "August",
//     "September",
//     "October",
//     "November",
//     "December",
//   ];

//   document.querySelector(".date h1").innerHTML = months[date.getMonth()];

//   document.querySelector(".date p").innerHTML = new Date().toDateString();

//   let days = "";

//   for (let x = firstDayIndex; x > 0; x--) {
//     days += `<div class="prev-date">${prevLastDay - x + 1}</div>`;
//   }

//   for (let i = 1; i <= lastDay; i++) {
//     if (
//       i === new Date().getDate() &&
//       date.getMonth() === new Date().getMonth()
//     ) {
//       days += `<div class="today">${i}</div>`;
//     } else {
//       days += `<div>${i}</div>`;
//     }
//   }

//   for (let j = 1; j <= nextDays; j++) {
//     days += `<div class="next-date">${j}</div>`;
//     monthDays.innerHTML = days;
//   }
// };

// document.querySelector(".prev").addEventListener("click", () => {
//   date.setMonth(date.getMonth() - 1);
//   renderCalendar();
// });

// document.querySelector(".next").addEventListener("click", () => {
//   date.setMonth(date.getMonth() + 1);
//   renderCalendar();
// });

// renderCalendar();
