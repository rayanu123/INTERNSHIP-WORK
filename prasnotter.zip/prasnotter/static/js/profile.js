navbar=document.querySelector(".navbar").querySelectorAll("a");

navbar.forEach(element => {
    element.addEventListener("click",function(){
        navbar.forEach(nav=>nav.classList.remove("active"))
        this.classList.add("active");
    })
});
$(document).ready(function(){
    var Name1=$('#name1').text();
    var str2 = Name1.match(/\b(\w)/g);
    console.log(str2);
    if(str2[1]===undefined){
      var intials = str2[0];
    }
    else{
      var intials = str2[0]+str2[1];
    }
    var profileImage = $('#profileImage').text(intials);
  });

  $(document).ready(function(){
    var Name=$('#name').text();
    var str1 = Name.match(/\b(\w)/g);
    if(str1[1]===undefined){
      var intials1 = str1[0];
    }
    else{
      var intials1 = str1[0]+str1[1];
    }
    var profileImage1 = $('#profileImage1').text(intials1);
  });


  $(document).ready(function(){
    var Name=$('#name2').text();
    var str2 = Name.match(/\b(\w)/g);
    if(str2[1]===undefined){
      var intials2 = str2[0];
    }
    else{
      var intials2 = str2[0]+str2[1];
    }
    var profileImage1 = $('#profileImage2').text(intials2);
  });
  
  
  